# 栖光 · 情感陪伴 Agent 前端原型

## 运行

直接双击 `index.html`，或在目录内启动静态服务器：

```bash
python -m http.server 8080
```

随后访问 `http://localhost:8080`。

## 界面结构

- 左侧不再展示会话历史，改为伴侣的实时状态：心跳、正在想什么、正在做的事和所处氛围。
- 心跳使用纯 CSS 动画；用户发送不同情绪的消息后，BPM、状态文案和动作会动态变化。
- 中间为沉浸式聊天主界面。
- 右侧展示长期记忆、陪伴偏好和近期互动节奏。

## 模型输出约定

```xml
<system_thinking>...</system_thinking>
<role_thinking>...</role_thinking>
<role_action>...</role_action>
最终回复文本
```

- `system_thinking`：生产环境必须由服务端或 API 网关剥离，绝不能发送到浏览器；原型中的本地字符串只用于演示解析。
- `role_thinking`：作为“她未说出口的话”，默认折叠，也可用于生成左栏中更抽象、安全的“在想什么”状态。
- `role_action`：作为轻量舞台动作，显示在回复气泡上方，也可映射到左栏“正在做的事”。
- 最终回复：作为聊天正文显示。

`index.html` 中的 `parseModelOutput(raw)` 可直接替换为真实流式接口的解析逻辑。

## 生产接入建议

后端将模型原始输出解析成以下安全响应，再交给前端：

```json
{
  "role_thinking": "...",
  "role_action": "...",
  "reply": "...",
  "presence": {
    "heart_rate": 68,
    "thought": "...",
    "activity": "..."
  }
}
```

不要把包含 `system_thinking` 的原始文本放进 SSE、WebSocket、日志埋点或浏览器状态。解析器同时兼容完整 XML 标签，以及以 `</system_thinking>`、`</role_thinking>` 作为边界的训练输出格式。
